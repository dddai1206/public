import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class ToshinMain {
	public static final String DELIMITER = ",";
	public static final String[] OUTPUT_HEADER = {"�����ԍ�", "�����R�[�h", "�擾��", "����敪", "��������", "�c������", "�P��", "�����ō��ݎ萔��", "�擾�P��",};
	public static final String[] INPUT_HEADER = {"���X�R�[�h", "�����ԍ�", "�t�@���h�R�[�h", "����", "����敪", "����", "���Z���z", "���ʔz�����P��", "���ɓ��敪", "�O���t���O", "���������ێ������敪","���P��", "�萔��", "�����"};
//	public static final String FILE_NAME = "C:\\Users\\81906\\eclipse-workspace\\Shinsei\\src\\sample01.csv";
//	public static final String OUTPUT_FILE_NAME = "C:\\Users\\81906\\OneDrive\\�f�X�N�g�b�v\\shinsei\\sample\\out_sample01.csv";
	public static final String INPUT_FILE_PATH = ".\\input";
	public static final String INPUT_FILE_NAME = "input.csv";
	public static final String INPUT_FILE_PATH_AND_NAME = INPUT_FILE_PATH + "\\" + INPUT_FILE_NAME;
	public static final String OUTPUT_FILE_PATH = ".\\output";
	public static final String OUTPUT_FILE_NAME = "result.csv";
	public static final String OUTPUT_FILE_PATH_AND_NAME = OUTPUT_FILE_PATH + "\\" + OUTPUT_FILE_NAME;
	
	public static void main(String[] args) throws IOException {
		long startTime = System.currentTimeMillis();
		System.out.println("[START]");
		ToshinMain.execute(ToshinMain.INPUT_FILE_PATH_AND_NAME, ToshinMain.OUTPUT_FILE_PATH_AND_NAME);
		long endTime = System.currentTimeMillis();
		System.out.println("[END]  TIME : " + (endTime - startTime) + "ms.");
		
	}
	
	public static void execute(String inputFilePathAndName, String outputFilePathAndName) throws IOException {
	
		File file = null;
		FileReader fr = null;
		BufferedReader br = null;
		ArrayList<ArrayList<String> > headerArrayList = new ArrayList<ArrayList<String> >();
		headerArrayList.add(new ArrayList<String>(Arrays.asList(ToshinMain.OUTPUT_HEADER)));
		ToshinMain.writeFile(headerArrayList, outputFilePathAndName);
		
		try {
			file = new File(inputFilePathAndName);
			fr = new FileReader(file);
			br = new BufferedReader(fr);
			String line = null;
			String beforeKey = "INITIAL_KEY";
			ArrayList<ArrayList<String> > tradeList = new ArrayList<ArrayList<String> >();
			while((line = br.readLine()) != null) {
	
				String[] splitLine = line.split(ToshinMain.DELIMITER);
				String accountNo = splitLine[ToshinMain.getInputHeaderIndex("�����ԍ�")].trim();
				String productCode = splitLine[ToshinMain.getInputHeaderIndex("�t�@���h�R�[�h")].trim();
				String key = accountNo + "_" + productCode;
				
				if(beforeKey.equals("INITIAL_KEY")) beforeKey = key;
				if(!beforeKey.equals(key)) {
					ToshinMain.createFile(beforeKey, tradeList, outputFilePathAndName);
					tradeList = new ArrayList<ArrayList<String> >();
					beforeKey = key;
				}
				
				ArrayList<String> trade = new ArrayList<String>();			
				for(int i = 0; i < splitLine.length ; i++) {
					trade.add(splitLine[i].trim());
				}
				tradeList.add(trade);
			}
			ToshinMain.createFile(beforeKey, tradeList, outputFilePathAndName);
		}catch(IOException e) {
			e.printStackTrace();
			throw e;
		}finally {
			br.close();
		}
	}
	
	public static ArrayList<String> sumList(ArrayList<ArrayList<String> > tradeList){
		ArrayList<String> result = new ArrayList<String>();
		String aggTradeType = "";
		int sumNum = 0;
		int sumRestNum = 0;
		double aveUnit = 0;
		double aveTotalTaxFee = 0;
		int sumTotalAmount = 0;
		
		for(int i = 0; i < tradeList.size(); i++) {
			ArrayList<String> trade = tradeList.get(i);
			
			String tradeType = trade.get(ToshinMain.getOutHeaderIndex("����敪"));
			if(i != 0) aggTradeType = aggTradeType + "/"; 
			aggTradeType = aggTradeType + tradeType;
			
			String num = trade.get(ToshinMain.getOutHeaderIndex("��������"));
			sumNum += Integer.parseInt(num);
			
			String restNum = trade.get(ToshinMain.getOutHeaderIndex("�c������"));
			sumRestNum += Integer.parseInt(restNum);
					
			String unit = trade.get(ToshinMain.getOutHeaderIndex("�P��"));
			aveUnit += (Double.parseDouble(unit) * Double.parseDouble(restNum));
			
			String totalTaxFee = trade.get(ToshinMain.getOutHeaderIndex("�����ō��ݎ萔��"));
			aveTotalTaxFee += Double.parseDouble(totalTaxFee) * Double.parseDouble(restNum) / Double.parseDouble(num);
			
			String totalAmount = trade.get(ToshinMain.getOutHeaderIndex("�擾�P��"));
			sumTotalAmount += Integer.parseInt(totalAmount);
			
			if(i == tradeList.size()-1) {	
				String accountNo = trade.get(ToshinMain.getOutHeaderIndex("�����ԍ�"));
				String productCode = trade.get(ToshinMain.getOutHeaderIndex("�����R�[�h"));
				String tradeDate = trade.get(ToshinMain.getOutHeaderIndex("�擾��"));
				aveUnit = aveUnit / (double)sumRestNum;
				result.add(ToshinMain.getOutHeaderIndex("�����ԍ�"), accountNo);
				result.add(ToshinMain.getOutHeaderIndex("�����R�[�h"), productCode);
				result.add(ToshinMain.getOutHeaderIndex("�擾��"), tradeDate);
				result.add(ToshinMain.getOutHeaderIndex("����敪"), aggTradeType);
				result.add(ToshinMain.getOutHeaderIndex("��������"), String.valueOf(sumNum));
				result.add(ToshinMain.getOutHeaderIndex("�c������"), String.valueOf(sumRestNum));
				result.add(ToshinMain.getOutHeaderIndex("�P��"), String.valueOf(String.valueOf(aveUnit)));
				result.add(ToshinMain.getOutHeaderIndex("�����ō��ݎ萔��"), String.valueOf((double)(sumTotalAmount - (int)(aveUnit * sumRestNum / 10000)) * (double)sumNum / (double)sumRestNum));
				result.add(ToshinMain.getOutHeaderIndex("�擾�P��"), String.valueOf(sumTotalAmount));			
			}		
		}
		return result;
	}
	
	public static void createFile(String key, ArrayList<ArrayList<String> > tradeList, String outputFilePathAndName) throws IOException {
		//�K�v�Ȃ�\�[�g����
		System.out.println("--execute   " + key);
		ArrayList<ArrayList<String> > resultTradeList = ToshinMain.calcToshin(tradeList);
		ToshinMain.writeFile(resultTradeList, outputFilePathAndName);
		System.out.println("  completed " + key);


	}

	
	public static ArrayList<ArrayList<String> > calcToshin(ArrayList<ArrayList<String> > inTradeList) {
		ArrayList<ArrayList<String> > resultTradeList = new ArrayList<ArrayList<String> >();
		
		for(ArrayList<String> inTrade : inTradeList) {
			int indexTradeType = ToshinMain.getInputHeaderIndex("����敪");
			int tradeType = Integer.parseInt(inTrade.get(indexTradeType));
			if(tradeType == 1 || tradeType == 4 || tradeType == 9) {
				ToshinMain.calcBuy(resultTradeList, inTrade);
			}else if(tradeType == 2 || tradeType == 10) {
				ToshinMain.calcSell(resultTradeList, inTrade);
			}else if(tradeType == 8) {
				ToshinMain.calcSpecialDividend(resultTradeList, inTrade);
			}
		}
		
		ToshinMain.calcFinal(resultTradeList);
		ArrayList<ArrayList<String> > sumTradeList = new ArrayList<ArrayList<String> >();
		sumTradeList.add(ToshinMain.sumList(resultTradeList));

		
		return sumTradeList;
		
	}
	
	public static void calcFinal(ArrayList<ArrayList<String> > resultTradeList) {
		for(ArrayList<String> trade: resultTradeList) {
			int restNum = Integer.parseInt(trade.get(ToshinMain.getOutHeaderIndex("�c������")));
			int num = Integer.parseInt(trade.get(ToshinMain.getOutHeaderIndex("��������")));
			double unitAmount = Double.parseDouble(trade.get(ToshinMain.getOutHeaderIndex("�P��")));
			double totalTaxFee = Double.parseDouble(trade.get(ToshinMain.getOutHeaderIndex("�����ō��ݎ萔��")));
			int totalAmount = (int)((double)restNum*unitAmount/10000 + 0.5) + (int)(totalTaxFee*(double)restNum/(double)num + 0.5);
			trade.set(ToshinMain.getOutHeaderIndex("�擾�P��"), String.valueOf(totalAmount));
		}
	}
	
	
	public static void calcBuy(ArrayList<ArrayList<String> > resultTradeList, ArrayList<String> inTrade) {
		//input
		String inAccountNum = inTrade.get(ToshinMain.getInputHeaderIndex("�����ԍ�"));
		String inProductNum = inTrade.get(ToshinMain.getInputHeaderIndex("�t�@���h�R�[�h"));
		String inTradeDate = inTrade.get(ToshinMain.getInputHeaderIndex("����"));
		String inTradeType = inTrade.get(ToshinMain.getInputHeaderIndex("����敪"));
		String inNum = inTrade.get(ToshinMain.getInputHeaderIndex("����"));
		String inAmount = inTrade.get(ToshinMain.getInputHeaderIndex("���Z���z"));
		String inUnit = inTrade.get(ToshinMain.getInputHeaderIndex("���P��"));
		String inTax =  inTrade.get(ToshinMain.getInputHeaderIndex("�����"));
		String inFee =  inTrade.get(ToshinMain.getInputHeaderIndex("�萔��"));
		//output 
		ArrayList<String> trade = ToshinMain.createNullArrayList(ToshinMain.OUTPUT_HEADER.length);
		trade.set(ToshinMain.getOutHeaderIndex("�����ԍ�"), inAccountNum);
		trade.set(ToshinMain.getOutHeaderIndex("�����R�[�h"), inProductNum);
		trade.set(ToshinMain.getOutHeaderIndex("�擾��"), inTradeDate);
		trade.set(ToshinMain.getOutHeaderIndex("����敪"), inTradeType);
		trade.set(ToshinMain.getOutHeaderIndex("��������"), inNum);
		trade.set(ToshinMain.getOutHeaderIndex("�c������"), inNum);
		trade.set(ToshinMain.getOutHeaderIndex("�P��"), inUnit);
		
		double totalTaxFee = Double.parseDouble(inTax) + Double.parseDouble(inFee);
		trade.set(ToshinMain.getOutHeaderIndex("�����ō��ݎ萔��"), String.valueOf(totalTaxFee));
		//double unitAmount = Double.parseDouble(inAmount) / Double.parseDouble(inNum); 
		//trade.set(ToshinMain.getOutHeaderIndex("�P��"), String.valueOf(unitAmount));
		resultTradeList.add(trade);
	}
	public static ArrayList<String> createNullArrayList(int size){
		ArrayList<String> result = new ArrayList<String>();
		for(int i = 0; i < size; i++) {
			result.add(null);
		}
		return result;
	}
	
	public static void calcSell(ArrayList<ArrayList<String> > resultTradeList, ArrayList<String> inTrade) {
		int sellNum = Integer.parseInt(inTrade.get(ToshinMain.getInputHeaderIndex("����")));
		int indexNum = ToshinMain.getOutHeaderIndex("�c������");
		for(ArrayList<String> trade: resultTradeList) {
			int num = Integer.parseInt(trade.get(indexNum));
			if(num == 0) continue;
			num = num - sellNum;
			if(num < 0) {
				sellNum = -1*num;
				num = 0;
			}else sellNum = 0;
			trade.set(indexNum, String.valueOf(num));
			if(sellNum == 0) return;
		}
	}
	
	public static void calcSpecialDividend(ArrayList<ArrayList<String> > resultTradeList, ArrayList<String> inTrade) {
		double unitSpecialDividend =  Double.parseDouble(inTrade.get(ToshinMain.getInputHeaderIndex("���ʔz�����P��")));
		int indexUnitAmount = ToshinMain.getOutHeaderIndex("�P��");
		for(ArrayList<String> trade: resultTradeList) {
			double unitAmount = Double.parseDouble(trade.get(indexUnitAmount));
			unitAmount -= unitSpecialDividend;
			trade.set(indexUnitAmount, String.valueOf(unitAmount));
		}
	}
	
	
	public static int getInputHeaderIndex(String headerName) {
		for(int i = 0; i < ToshinMain.INPUT_HEADER.length; i++) {
			if(ToshinMain.INPUT_HEADER[i].equals(headerName)) return i;
		}
		return -1;
	}
	
	public static int getOutHeaderIndex(String headerName) {
		for(int i = 0; i < ToshinMain.OUTPUT_HEADER.length; i++) {
			if(ToshinMain.OUTPUT_HEADER[i].equals(headerName)) return i;
		}
		return -1;
	}
	
	public static ArrayList<ArrayList<String> > readFile(String fileName) throws IOException{
		ArrayList<ArrayList<String> > tradeList = new ArrayList<ArrayList<String> >();
		File file = new File(fileName);
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		String line = null;
		
		while((line = br.readLine()) != null) {
			String[] splitLine = line.split(ToshinMain.DELIMITER);
			ArrayList<String> trade = new ArrayList<String>();
			for(int i = 0; i < splitLine.length ; i++) {
				trade.add(splitLine[i].trim());
			}
			tradeList.add(trade);
		}
		br.close();
		return tradeList;
	}
	
	public static void writeFile(ArrayList<ArrayList<String> > resultTradeList, String fileName) throws IOException{
		File file = null;
		FileWriter fw = null;
		BufferedWriter bw = null;
		try {
			file = new File(fileName);
			fw = new FileWriter(file, true);
			bw = new BufferedWriter(fw);
			for(ArrayList<String> trade: resultTradeList) {
				String line = "";
				for(int i = 0; i < trade.size(); i++) {
					if(i!=0) line += ToshinMain.DELIMITER;
					line += trade.get(i);
				}
				bw.write(line);
				bw.newLine();
			}
		}catch(IOException e) {
			e.printStackTrace();
			throw e;
		}finally {
			bw.close();
		}
	}
}
